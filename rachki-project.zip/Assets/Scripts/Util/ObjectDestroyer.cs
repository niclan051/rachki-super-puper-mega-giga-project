﻿using UnityEngine;

namespace Util {
    public class ObjectDestroyer : MonoBehaviour { public void DestroyObject(GameObject objectToDestroy) => Destroy(objectToDestroy); }
}