﻿using UnityEngine;

namespace Util {
    public class Ragequitter : MonoBehaviour {
        public void Ragequit() => Application.Quit();
    }
}