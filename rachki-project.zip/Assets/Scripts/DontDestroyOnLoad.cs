﻿using System;
using UnityEngine;

public class DontDestroyOnLoad : MonoBehaviour {
    private void Start() {
        DontDestroyOnLoad(gameObject);
    }
}